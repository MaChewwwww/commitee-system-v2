<?php
/**
 * InfinityFree production configuration.
 *
 * DO NOT commit or share this file.
 * Keep real passwords/API keys only on the server.
 */

return [
    // App is deployed at the domain root.
    'COMMITTEE_APP_BASE' => '',

    // =========================================================
    // DATABASE — Local MySQL
    // =========================================================
    'COMMITTEE_DB_HOST' => '127.0.0.1',
    'COMMITTEE_DB_PORT' => '3306',
    'COMMITTEE_DB_NAME' => 'committee_management',
    'COMMITTEE_DB_USER' => 'root',
    'COMMITTEE_DB_PASSWORD' => 'root',

    // =========================================================
    // SMTP — Gmail
    // =========================================================
    'COMMITTEE_SMTP_HOST' => 'smtp.gmail.com',
    'COMMITTEE_SMTP_PORT' => '587',
    'COMMITTEE_SMTP_USER' => 'caranyagan.johnpaul.bueno@gmail.com',
    'COMMITTEE_SMTP_PASSWORD' => 'wjcm rsmb trrw ewlq',
    'COMMITTEE_SMTP_FROM' => 'caranyagan.johnpaul.bueno@gmail.com',
    'COMMITTEE_SMTP_FROM_NAME' => 'SK Committee System',
    'COMMITTEE_SMTP_SECURE' => 'tls',
    
    // =========================================================
    // GEMINI AI (configured in .env)
    // =========================================================
    'COMMITTEE_GEMINI_API_KEY' => '',
    
    
];